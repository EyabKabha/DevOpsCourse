from Live import load_game, welcome

#call welcome function
print(welcome('Eyab'))

#start the game
load_game()